"""
Report module for Security Testing Framework
Contains report generation and analysis components
"""