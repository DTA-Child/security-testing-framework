"""
Scanners module for Security Testing Framework
Contains scanner implementations (ZAP, Nuclei, Nikto)
"""