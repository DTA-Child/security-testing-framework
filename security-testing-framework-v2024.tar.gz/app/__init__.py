"""
Security Testing Framework
Comprehensive web application security scanning with OWASP ZAP, Nuclei, and Nikto
"""

__version__ = "1.0.0"
__author__ = "Security Team"