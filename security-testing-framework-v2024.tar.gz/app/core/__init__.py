"""
Core module for Security Testing Framework
Contains configuration and orchestration components
"""