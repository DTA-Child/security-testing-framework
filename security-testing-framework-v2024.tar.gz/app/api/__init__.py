"""
API module for Security Testing Framework
Contains REST API routes and endpoints
"""