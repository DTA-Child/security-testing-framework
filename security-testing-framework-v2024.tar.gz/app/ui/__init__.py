"""
UI module for Security Testing Framework
Contains web and CLI interfaces
"""